// 📁 mathUtils.js

// Simple function export
export function add(a, b) {
  return a + b;
}

// Another function export
export function multiply(a, b) {
  return a * b;
}

// Named constant export
export const PI = 3.14159;

// Default export (ek hi file me ek hi default export hota hai)
export default function greet(name) {
  console.log(`Hello, ${name}!`);
}
