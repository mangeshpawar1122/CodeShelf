// 📁 main.js

// Named imports - {} ke andar likhna padta hai
import { add, PI ,multiply } from './02_mathUtils.js';





// Default import - kisi bhi naam se le sakte ho
import greet from './02_mathUtils.js';

// Functions ka use kar rahe hain
console.log("Addition: ", add(10, 5));         // 15
console.log("Multiplication: ", multiply(4, 3)); // 12
console.log("Value of PI: ", PI);              // 3.14159

// Greet function (default export)
greet("Meghraj"); // Hello, Meghraj!
greet("Vijay"); // Hello, Meghraj!
