// Create a promise that resolves after 1 second
const promiseSix = new Promise((resolve, reject) => {
  setTimeout(() => {
    let error = false; // Change to true to test rejection
    if (!error) {
      resolve({ name: "Javascript", password: 12345 }); // Resolves with data
    } else {
      reject("ERROR: Something went wrong"); // Rejects with error
    }
  }, 1000);
});

// Async function to consume the promise
async function consumePromiseSix() {
  try {
    const response = await promiseSix; // Waits for the promise to resolve
    console.log(response); // Logs the resolved data
  } catch (error) {
    console.log(error); // Catches and logs the error if promise is rejected
  }
}

consumePromiseSix(); // Call the async function
