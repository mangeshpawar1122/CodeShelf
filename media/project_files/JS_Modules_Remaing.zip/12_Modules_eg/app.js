// ✅ user.js se named imports
import { name, code, withdraw } from "./user.js";

// ✅ Agar aap sab kuch ek object me import karna chahte ho
import * as usr from "./user.js";
usr.code(); // ✅ Function exported tha isliye kaam karega
// usr.cook(); // ❌ Error - kyunki cook() exported nahi hai

// ✅ account.js se default + named imports
import { default as dfault, withdraw as wd, deposit } from "./account.js";
dfault();     // Default function from account.js
withdraw();   // From user.js
wd();         // From account.js (renamed to avoid conflict)
deposit();    // From account.js

// ✅ account.js se variables import
import { accountNumber, accType, accBalance, accHolderName } from "./account.js";

// ✅ Data print kar rahe hain
console.log(name); // Meghraj

// ❌ age export nahi hua user.js se
// console.log(age); // ❌ Error

// ✅ user.js se imported function call
code(); // "Coding..."
