// ✅ Default export (ye file ka main function hai)
export default function () {
  console.log("Account Default function called.");
}

// ✅ Named variables for account info
let accountNumber = 4093759;
let accType = "Savings";
let accBalance = 50000;
let accHolderName = "Meghraj";

// ✅ Exported functions
export function withdraw() {
  console.log("💸 Amount Withdraw.");
}

export function deposit() {
  console.log("💰 Balance Updated...");
}

// ✅ Exporting variables (named export)
export { accountNumber, accType, accBalance, accHolderName };
