// ✅ Default export (ek file me sirf ek hi default export hota hai)
export default function () {
    console.log("User Default function called.");
}

// ✅ Named export - ye variable import karke kahin bhi use kar sakte ho
export let name = "Meghraj";

// ❌ Private variables - export nahi kiye gaye, sirf is file me kaam karenge
let age = 25;
let city = "Nanded";

// ✅ Named exports - ye functions import karke kahin bhi use kar sakte ho
export function withdraw() {
    console.log("💸 Amount Deducted from your account.");
}

export function code() {
    console.log("Coding...");
}

// ❌ Private function - export nahi kiya gaya
function cook() {
    console.log("Cooking...");
}
