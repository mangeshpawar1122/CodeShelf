// import { circle } from "./13_Modules/shapes/circle.js";
// import { triangle } from "./13_Modules/shapes/triangle.js";
// import { square } from "./13_Modules/shapes/square.js";


import { circle, triangle, square } from "./13_Modules/shape.js";



circle();
triangle();
square();  