export function square() {
    console.log("Square function Called...");

}