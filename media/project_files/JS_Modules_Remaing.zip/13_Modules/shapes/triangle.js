export function triangle() {
    console.log("Triangle function Called...");

}